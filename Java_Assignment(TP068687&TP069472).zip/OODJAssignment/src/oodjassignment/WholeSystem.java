package oodjassignment;
import java.util.Scanner;
import static oodjassignment.Validation.validateChoice;

public abstract class WholeSystem {
    Scanner sr = new Scanner(System.in);
    public abstract void add();
    public abstract void edit();
    public abstract void delete();
    public abstract void view();
    public abstract void search();
    
    private int continueChoice(int num) {
        while (true) {
            System.out.println("\nDo you want to continue this section? (yes/no): ");
            String continueChoice = sr.nextLine().trim().toLowerCase();
            switch (continueChoice) {
                case "yes":
                    return num;
                case "no":
                    return -1;
                default:
                    System.out.println("\nInvalid option!\n");
                    break;
            }
        }
    }

    public void generalMenu(String title) {
        int choice = 0;
        while (choice != 6) {
            if (choice >= 1 && choice <= 5) {
                performOperation(choice);
            } else {
                displayMenuOptions(title);
                choice = validateChoice(1, 6);
                performOperation(choice);
            }
            if(choice != 6){
                choice = continueChoice(choice);
            }
        }
    }

    private void performOperation(int choice) {
        switch (choice) {
            case 1:
                add();
                break;
            case 2:
                edit();
                break;
            case 3:
                delete();
                break;
            case 4:
                view();
                break;
            case 5:
                search();
                break;
            case 6:
                break;
            default:
                System.out.println("\nPlease choose valid option!\n");
        }
    }

    private void displayMenuOptions(String title) {
        String symbol = "*".repeat(title.length());
        System.out.println("\n" + symbol + "\n" + title + "\n" + symbol + "\n");
        System.out.println("1. Add.");
        System.out.println("2. Edit.");
        System.out.println("3. Delete.");
        System.out.println("4. View.");
        System.out.println("5. Search.");
        System.out.println("6. Exit.");
        System.out.println("\nEnter your choice: ");
    }
}
