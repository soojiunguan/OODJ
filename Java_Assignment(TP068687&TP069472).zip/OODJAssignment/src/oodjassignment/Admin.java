package oodjassignment;
import static oodjassignment.Validation.validateChoice;

public class Admin extends Staff{
    Item it = new Item();
    Supplier sp = new Supplier();
    DailySalesEntry ds = new DailySalesEntry();
    PurchaseRequisition pr = new PurchaseRequisition(getUsername());
    PurchaseOrder po = new PurchaseOrder(getUsername());

    public Admin(String username) {
        super(username);
    }

    public void menu(){
        while(true){
            System.out.println("\n**********");
            System.out.println("Admin Menu");
            System.out.println("**********\n");
            System.out.println("1. Item Entry.");
            System.out.println("2. Supplier Entry.");
            System.out.println("3. Daily Item-wise Sales Entry.");
            System.out.println("4. Purchase Requisition Entry.");
            System.out.println("5. Purchase Order Entry.");
            System.out.println("6. Register New Staff.");
            System.out.println("7. Update Staff's Info.");
            System.out.println("8. Delete Existing Staff.");
            System.out.println("9. Search Existing Staff.");
            System.out.println("10. View own info.");
            System.out.println("11. Log out.");
            System.out.print("\nEnter your choice: ");
            int choice = validateChoice(1,11);
            switch(choice){
                case 1:
                    it.menu();
                    break;
                case 2:
                    sp.menu();
                    break;
                case 3:
                    ds.menu();
                    break;
                case 4:
                    pr.menu();
                    break;
                case 5:
                    po.menu();
                    break;
                case 6:
                    Staff sf1 = new Staff();
                    sf1.addStaff();
                    break;
                case 7:
                    Staff sf2 = new Staff(getUsername());
                    sf2.updateInfo();
                    break;
                case 8:
                    Staff sf3 = new Staff(getUsername());
                    sf3.deleteStaff();
                    break;
                case 9:
                    Staff sf4 = new Staff();
                    sf4.searchStaff();
                    break;
                case 10:
                    Staff sf5 = new Staff(getUsername());
                    sf5.viewOwnInfo();
                    break;
                case 11:
                    System.out.println("\nSee you again," + getUsername() + ".\n");
                    Staff sf6 = new Staff();
                    sf6.login();
                default:
                    break;
            }
        }
    }
    
}

