package oodjassignment;
import java.util.*;
import static oodjassignment.Validation.*;

public class PurchaseRequisition extends WholeSystem implements Function{
    enum Status{
        Pending,
        Approve,
        Reject,
        Expired,
        INVALID
    }
    private String PRCode, itemCode,  requiredDate, supplierCode, salesManager;
    private int quantity;
    private Status status;
    private final String PREFIX = "PR";
    FileHandle prfh = new FileHandle("PR.txt");
    FileHandle itfh = new FileHandle("item.txt");
    FileHandle pofh = new FileHandle("PO.txt");
    FileHandle cmfh = new FileHandle("comment.txt");
    
    public PurchaseRequisition(){
    }
    
    public PurchaseRequisition(String PRCode, String itemCode, int quantity, String requiredDate, String supplierCode, String salesManager, Status status) {
        this.PRCode = PRCode;
        this.itemCode = itemCode;
        this.quantity = quantity;
        this.requiredDate = requiredDate;
        this.supplierCode = supplierCode;
        this.salesManager = salesManager;
        this.status = status;
    }

    public PurchaseRequisition(String salesManager){
        this.salesManager = salesManager;
    }
    
    @Override
    public String toString() {
        return  PRCode + "," + itemCode + "," + quantity + "," + requiredDate + "," + supplierCode + "," + salesManager + "," + status;
    }
    public void setPRCode(String PRCode) {
        this.PRCode= PRCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setRequiredDate(String requiredDate) {
        this.requiredDate = requiredDate;
    }

    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public void setSalesManager(String salesManager) {
        this.salesManager = salesManager;
    }

    public String getPRCode() {
        return PRCode;
    }
    public Status getStatus(){
        return status;
    }
    
    public void setStatus() {
        this.status = Status.Pending;
    }
  
    public String getItemCode() {
        return itemCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getRequiredDate() {
        return requiredDate;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public String getSalesManager() {
        return salesManager;
    }

    @Override
    public void add() {
        setPRCode(prfh.generateId(PREFIX));
        boolean continueAdding = true;
        System.out.println("Please enter its required date: ");
        String InputDate = validateDate(sr.nextLine());
        setRequiredDate(InputDate);
        while(continueAdding) {
            System.out.println("\nPlease enter item code: ");
            String[] ItemCodeInput = itfh.isIdExists(sr.nextLine());
            setItemCode(ItemCodeInput[0]);
            System.out.println("Please enter its quantity: ");
            setQuantity(sr.nextInt());
            sr.nextLine();
            // get supplier id from item.txt
            setSupplierCode(itfh.isIdExists(getItemCode())[3]);
            setStatus();
            System.out.println("\nCongratulations! item added successfully!\n");
            prfh.write(toString());
            System.out.println("\nDo you want to add another item? (yes/no)");
            String userInput = sr.nextLine().trim().toLowerCase();
            if (!userInput.equals("yes")) {
                continueAdding = false;
            }
        }
    }

    @Override
    public void edit() {
        System.out.println("\nPlease provide PR code that you wish to edit: ");
        String[] PRToUpdate = prfh.isIdExists(sr.nextLine());
        if(PRToUpdate[6].equals("Expired")){
            System.out.println("This PR is alredy expired, please create the new Purchase Requisition");
        }
        else {
            List<String> allPRs = prfh.read();
            List<String> prCodesToEdit = new ArrayList<>();
            List<String> prCodesNotToEdit = new ArrayList<>();
            for (String line : allPRs) {
                String[] prData = line.split(",");
                if (prData[0].equals(PRToUpdate[0])) {
                    prCodesToEdit.add(line);
                } else {
                    prCodesNotToEdit.add(line);
                }
            }
            System.out.println("\nPR Lines for Editing:");
            showResult(prCodesToEdit);
            System.out.println("\n" + String.valueOf(Integer.toString(prCodesToEdit.size() + 1)) + ". Edit Required Date");
            System.out.println("\nPlease choose which PR line to edit (1-" + String.valueOf(Integer.toString(prCodesToEdit.size() + 1)) + "): ");
            int choice = validateChoice(1, prCodesToEdit.size()+1);
            String[] prData = null;
            if (choice <= prCodesToEdit.size()) { 
                String selectedPRLine = prCodesToEdit.get(choice - 1);
                prData = selectedPRLine.split(",");
                String[] fieldNames = {"Item Code", "Quantity"};
                System.out.println("\nChoose which field to edit within this PR line:");
                for (int i = 0; i < fieldNames.length; i++) {
                    System.out.println((i + 1) + ". " + fieldNames[i]);
                }
                System.out.println("\nEnter your choice: ");
                int editChoice = validateChoice(1, fieldNames.length);
                switch (editChoice) {
                    case 1:
                        System.out.println("\nEnter new Item Code:");
                        String[] itemCodeInput = itfh.isIdExists(sr.nextLine());
                        prData[1] = itemCodeInput[0];
                        prData[4] = itemCodeInput[3];
                    case 2:
                        System.out.println("\nEnter new Quantity:");
                        int newQuantity = validateQuantityInput(sr.nextLine());
                        prData[2] = String.valueOf(newQuantity);
                        break;
                    default:
                        System.out.println("\nInvalid choice.\n");
                        return;
                }
                
                // if PR status already is approved or rejected, after edit specific PR the status reset to Pending.
                if (prData[6].equals("Approve") || prData[6].equals("Reject")) {
                    prData[6] = "Pending";
                    prCodesToEdit.set(choice - 1, String.join(",", prData));
                    for (int i = 0; i < prCodesToEdit.size(); i++) {
                        String[] data = prCodesToEdit.get(i).split(",");
                        data[6] = "Pending";
                        prCodesToEdit.set(i, String.join(",", data));
                    }
                }else{
                    prCodesToEdit.set(choice - 1, String.join(",", prData));
                }
            }else if (choice == prCodesToEdit.size() + 1) { //edit required date
                System.out.println("\nEnter new Required Date:");
                String InputDate = validateDate(sr.nextLine());
                for (int i = 0; i < prCodesToEdit.size(); i++) {
                    String[] data = prCodesToEdit.get(i).split(",");
                    data[3] = InputDate;
                    prCodesToEdit.set(i, String.join(",", data));
                }
            }else {
                System.out.println("Invalid choice for DS line.");
            }
            
            //after pr edited po will be deleted
            for (String line : pofh.read()) {
                String[] component = line.split(",");
                if (component[1].trim().equals(prData[0])) {
                    pofh.delete(component[0]);
                    Comment cm = new Comment(prData[0]);
                    cm.deleteComment();
                    break;
                }
            }
            System.out.println("\nCongratulations! The purchase requisition edited successfully!\n");
            //Save into file
            prfh.overwrite("");
            for (String prCode : prCodesNotToEdit) {
                prfh.write(prCode);
            }
            for (String prCode : prCodesToEdit) {
                prfh.write(prCode);
            }
        }
    }

    @Override
    public void delete() {
        System.out.println("\nPlease enter purchase requisition code that you want to delete: ");
        String[] idToDelete = prfh.isIdExists(sr.nextLine());
        System.out.println("\nCongratulations! The purchase requisition deleted successfully!\n");
        prfh.delete(idToDelete[0]);
        Comment cm = new Comment(idToDelete[0]);
        cm.deleteComment();
        List<String> allPOs = pofh.read();
        for (String line : allPOs) {
            String[] component = line.split(",");
            if (component[1].equals(idToDelete[0])) {
                pofh.delete(component[0]);
            }
        }
    }

    @Override
    public void view() {
        prfh.isFileEmpty();
        List<String> lines = prfh.read();
        showResult(lines);
    }
    
    @Override
    public void search() {
        System.out.println("\nPlease enter purchase requisition id you want to search: ");
        String searchCode = sr.nextLine(); 
        List<String> searchResults = prfh.searchMultipleLine(searchCode);
        showResult(searchResults);
    }
    
    @Override
    public void menu(){
        generalMenu("Purchase Requisition Menu");
    }
    
    public void getShowResult(List<String> lines){
        showResult(lines);
    }
    
    private void showResult(List<String> lines){
        if (lines == null) {
            System.out.println("\nNo purchase order found.\n");
        } else {
            Map<String, List<String>>  groupedPRs = new HashMap<>();
            for (String line : lines) {
                String[] prData = line.split(",");
                String prCode = prData[0];
                // check whether there is an existing group with the same PR code
                if (groupedPRs.containsKey(prCode)) {
                    groupedPRs.get(prCode).add(line);
                } else {
                    List<String> newGroup = new ArrayList<>();
                    newGroup.add(line);
                    groupedPRs.put(prCode, newGroup);
                }
            }
            for (Map.Entry<String, List<String>> entry : groupedPRs.entrySet()) {
                String prCode = entry.getKey();
                String date = entry.getValue().get(0).split(",")[3];
                String salesManager = entry.getValue().get(0).split(",")[5];
                String status = entry.getValue().get(0).split(",")[6];
                String formattedPrCode = String.format("|%10s", prCode);
                String formattedStatus = String.format("%-13s|", status);
                String formattedSM = String.format("%26s", salesManager);
                String symbol = "|---------------------------------------------------|";
                System.out.println("\n\n" + symbol + "\n|" + formattedSM + String.format("%25s|", " "));
                System.out.println(symbol + "\n" + formattedPrCode + String.format("%9s", " ") + String.format("%10s", date) + String.format("%9s", " ") + formattedStatus + "\n" + symbol);
                System.out.println("| Item Code      | Quantity       | Supplier Code   |");
                System.out.println("| ---------------| ---------------| ----------------|");
                for (String prLine : entry.getValue()) {
                    String[] prData = prLine.split(",");
                    String itemCode = prData[1];
                    int quantity = Integer.parseInt(prData[2]);
                    String supplierCode = prData[4];
                    String formattedItemCode = String.format("| %-15s", itemCode);
                    String formattedQuantity = String.format("| %-15d", quantity);
                    String formattedSupplierCode = String.format("| %-15s", supplierCode);
                    System.out.println(formattedItemCode + formattedQuantity + formattedSupplierCode + " |");
                    System.out.println("| ---------------| ---------------| ----------------|");
                    Comment cm = new Comment(prData[0]);
                    if(cm.readComment() != null){
                        String[] component = cm.readComment().split("\\|");
                        System.out.println("\nRejected By: " + component[1]);
                        System.out.println("Reason: " + component[2]);
                    }
                }
            }
        }
    }
    
}