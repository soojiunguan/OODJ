package oodjassignment;
import java.util.ArrayList;
import java.util.List;
import static oodjassignment.Validation.validateChoice;
import static oodjassignment.Validation.validateDate;
import static oodjassignment.Validation.validateQuantityInput;


public class PurchaseOrder extends WholeSystem {
    
    private String POCode, PRCode, purchaseManager, Date;
    private final String PREFIX = "PO";
    CurrentDate date = new CurrentDate();
    FileHandle pofh = new FileHandle("PO.txt");
    FileHandle prfh = new FileHandle("PR.txt");
    FileHandle itfh = new FileHandle("item.txt");
    
    
    public PurchaseOrder(){
    }
    
    public PurchaseOrder(String purchaseManager){
        this.purchaseManager = purchaseManager;
    }
    
    public PurchaseOrder(String POCode,String PRCode, String Date, String purchaseManager) {
        this.POCode = POCode;
        this.PRCode = PRCode;
        this.Date = Date;
        this.purchaseManager = purchaseManager;
    }

    @Override
    public String toString() {
        return  POCode + "," + PRCode + "," + Date + "," + purchaseManager;
    }

    public String getPOCode() {
        return POCode;
    }

    public void setPOCode(String POCode) {
        this.POCode = POCode;
    }

    public void setDate(){
        this.Date = date.toString();
    }
    public String getPRCode() {
        return PRCode;
    }

    public void setPRCode(String PRCode) {
        this.PRCode = PRCode;
    }

    public String getPurchaseManager() {
        return purchaseManager;
    }
    public String getDate(){
        return Date;
    }
    public void setPurchaseManager(String purchaseManager) {
        this.purchaseManager = purchaseManager;
    }

    private void setPRStatus(String id, String status){
        List<String> allPRs = prfh.read();
        List<String> prCodesToEdit = new ArrayList<>();
        List<String> prCodesNotToEdit = new ArrayList<>();

        for (String line : allPRs) {
            String[] prData = line.split(",");
            if (prData[0].equals(id)) {
                prCodesToEdit.add(line);
            } else {
                prCodesNotToEdit.add(line);
            }
        }
      
        for (int i = 0; i < prCodesToEdit.size(); i++) {
            String[] dsDATA = prCodesToEdit.get(i).split(",");
            if (dsDATA[0].equals(id)) {
                dsDATA[6] = status;
                prCodesToEdit.set(i, String.join(",", dsDATA));
            }
        }
        prfh.overwrite(""); //make the file become blank
        for (String prCode : prCodesNotToEdit) {
            prfh.write(prCode);
        }
        for (String prCode : prCodesToEdit) {
            prfh.write(prCode);
        }
    }
    
    @Override
    public void add() {
        List<String> prCanEdit = new ArrayList<>();
        List<String> allPRs = prfh.read();
        boolean isPrPending = false;
        for (String line : allPRs) {
            String[] component = line.split(",");
            if (component.length >= 7 && component[6].equals("Pending")) {
                prCanEdit.add(line);
                isPrPending = true; // Set to true if at least one "Pending" PR is found
            }
        }
        PurchaseRequisition pr = new PurchaseRequisition();
        pr.getShowResult(prCanEdit);
        setPOCode(pofh.generateId(PREFIX));
        if (!isPrPending) {
            System.out.println("\nNothing needs to be handled.\n");
        }
        else{
            while (isPrPending) {
                System.out.println("\nPlease enter PR code: ");
                String prCodeInput = sr.nextLine();
                boolean found = false; // Flag to check if a matching PR code is found
                for (String line : prCanEdit) {
                    String[] component = line.split(",");
                    if (component[0].equals(prCodeInput)) {
                        setPRCode(prCodeInput);
                        isPrPending = false;
                        found = true; // Set the flag to true when a matching PR code is found
                        break; // Exit the loop since a valid PR code was found
                    }
                }
                if (!found) {
                    System.out.println("\nPlease enter a valid choice!\n");
                }
            }
            String status = null;
            System.out.println("\n1.Approve    2.Reject    3.Exit");
            System.out.println("\nEnter your choice: ");
            int choice = validateChoice(1,3);
            switch (choice) {
                case 1:
                    status = "Approve";
                    break;
                case 2:
                    status = "Reject";
                    Comment cm = new Comment(getPRCode());
                    cm.setPurchaseManager(getPurchaseManager());
                    cm.writeComment();
                    break;
                case 3:
                    break;
                default:
                    System.out.println("\nInvalid Choice.\n");
                    break;
            }
            if (status != null) {
                setDate();
                if(status.equals("Approve")){
                    System.out.println("\nCongratulations! Purchase order added successfully!\n");
                    pofh.write(toString());
                }
                setPRStatus(getPRCode(),status);
            }
        }
    }
    
    @Override
    public void edit(){
    System.out.println("\nPlease provide PO code that you wish to edit: ");
        String[] POToUpdate = pofh.isIdExists(sr.nextLine());
        String[] temp1 = pofh.getIDinfo(POToUpdate[0]);
        List<String> temp2 = new ArrayList();
        String temp3 = String.join(",",temp1);
        temp2.add(temp3);
        List<String> allPRs = prfh.read();
        List<String> prCodesToEdit = new ArrayList<>();
        List<String> prCodesNotToEdit = new ArrayList<>();
        for (String line : allPRs) {
            String[] prData = line.split(",");
            if (prData[0].equals(POToUpdate[1])) {
                prCodesToEdit.add(line);
            } else {
                prCodesNotToEdit.add(line);
            }
        }
        System.out.println("\nPO Lines for Editing:");
        showResult(temp2);
        System.out.println("\n" + String.valueOf(Integer.toString(prCodesToEdit.size() + 1)) + ". Edit Required Date");
        System.out.println("\nPlease choose which PO line to edit (1-" + String.valueOf(Integer.toString(prCodesToEdit.size() + 1)) + "): ");
        int choice = validateChoice(1, prCodesToEdit.size()+1);
        String[] prData = null;
        if (choice <= prCodesToEdit.size()) {
            String selectedPRLine = prCodesToEdit.get(choice - 1);
            prData = selectedPRLine.split(",");
            String[] fieldNames = {"Item Code", "Quantity"};
            System.out.println("\nChoose which field to edit within this PO line:");
            for (int i = 0; i < fieldNames.length; i++) {
                System.out.println((i + 1) + ". " + fieldNames[i]);
            }
            System.out.println("\nEnter your choice: ");
            int editChoice = validateChoice(1, fieldNames.length);
            switch (editChoice) {
                case 1:
                    System.out.println("\nEnter new Item Code:");
                    String[] itemCodeInput = itfh.isIdExists(sr.nextLine());
                    prData[1] = itemCodeInput[0];
                    prData[4] = itemCodeInput[3];
                case 2:
                    System.out.println("\nEnter new Quantity:");
                    int newQuantity = validateQuantityInput(sr.nextLine());
                    prData[2] = String.valueOf(newQuantity);
                    break;
                default:
                    System.out.println("\nInvalid choice.\n");
                    return;
            }
            prCodesToEdit.set(choice - 1, String.join(",", prData));
        }else if (choice == prCodesToEdit.size() + 1) { //edit required date
            System.out.println("\nEnter new Required Date:");
            String InputDate = validateDate(sr.nextLine());
            for (int i = 0; i < prCodesToEdit.size(); i++) {
                String[] data = prCodesToEdit.get(i).split(",");
                data[3] = InputDate;
                prCodesToEdit.set(i, String.join(",", data));
            }
        }else {
            System.out.println("Invalid choice for PO line.");
        }
        System.out.println("\nCongratulations! The purchase order edited successfully!\n");
        //Save into file
        prfh.overwrite("");
        for (String prCode : prCodesNotToEdit) {
            prfh.write(prCode);
        }
        for (String prCode : prCodesToEdit) {
            prfh.write(prCode);
        }
    }
    

    @Override
    public void delete() {
        if(!pofh.isFileEmpty()){
            System.out.println("\nPlease enter purchase order code that you want to delete: ");
            String[] idToDelete = pofh.isIdExists(sr.nextLine());
                System.out.println("\nCongratulations! The purchase order deleted successfully!\n");
                pofh.delete(idToDelete[0]);
                List<String> allPRs = prfh.read();
                for (String line : allPRs) {
                String[] component = line.split(",");
                if (component[0].equals(idToDelete[1])) {
                    PurchaseRequisition pr = new PurchaseRequisition(component[0],component[1],Integer.parseInt(component[2]),component[3],component[4],component[5],PurchaseRequisition.Status.Pending);
                    prfh.edit(component[0],pr.toString());
                }
            }
        }
    }

    @Override
    public void view() {
        pofh.isFileEmpty();
        List<String> lines = pofh.read();
        showResult(lines);
    }

    @Override
    public void search(){
        List<String> allPRs = prfh.read();
        System.out.println("\nPlease enter purchase order code or purchase requisition code you want to search: ");
        String[] output = pofh.showSearchResult();
        if (output != null) {
            System.out.println("\npurchase order code: " + output[0] + "\nHandled purchase requisition code: " + output[1] + "\nApproved Date: " + output[2] + "\nHandled By: " + output[3]);
            int count = 1;
            for (String line2 : allPRs) {
                String[] component2 = line2.split(",");
                if (component2[0].equals(output[1])) {
                    if(count == 1){
                        System.out.println("Required Date: " + count + ": " + component2[3]);
                        System.out.println("\n~~~~Item section as below~~~~");
                    }
                    System.out.println("Item Code " + count + ": " + component2[1]);
                    System.out.println("Quantity " + ": " + component2[2]);
                    count ++;
                }
            }
        }
        else{
            System.out.println("\nNo results found.\n");
        }
    }
    
    public void menu(){
        generalMenu("Purchase Order Menu");
    }

    private void showResult(List<String> lines){
        if (lines == null) {
            System.out.println("\nNo purchase order found.\n");
        } else {
            List<String> allPRs = prfh.read();
            for (String line : lines) {
                String[] component = line.split(",");
                if (component.length != 0) {
                    System.out.println("\n\n*****************************");
                    System.out.println("\tPO Code: " + component[0]);
                    System.out.println("*****************************");
                    System.out.println("PR Code: " + component[1]);
                    int num = 1;
                    for (String line1 : allPRs) {
                        String[] component1 = line1.split(",");
                        if (component1[0].equals(component[1])) {
                            if(num == 1){
                                System.out.println("Required Date: " + component1[3]);
                            }
                            num ++;
                        }
                    }
                    System.out.println("Approved Date: " + component[2]);
                    System.out.println("Approved By: " + component[3]);
                    System.out.println("*****************************");
                    System.out.println("   Item section as below:");
                    System.out.println("*****************************");
                    int count = 1;
                    for (String line2 : allPRs) {
                        String[] component2 = line2.split(",");
                        if (component2[0].equals(component[1])) {
                            System.out.println("\033[35m" + "Item Code " + count + ": " + component2[1] + "\033[0m");
                            System.out.println("Quantity " + ": " + component2[2]);
                            count ++;
                        }
                    }
                    System.out.println("*****************************");
                }
            }
        }
    }
    
}

