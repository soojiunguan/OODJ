package oodjassignment;
import static oodjassignment.Validation.validateChoice;

public class PurchaseManager extends Staff{
    Item it = new Item();
    Supplier sp = new Supplier();
    PurchaseRequisition pr = new PurchaseRequisition();
    PurchaseOrder po = new PurchaseOrder(getUsername());

    public PurchaseManager(String username) {
        super(username);
    }
    
    public void menu(){
        while(true){
            System.out.println("\n*********************");
            System.out.println("Purchase Manager Menu");
            System.out.println("***********************\n");
            System.out.println("1.  List of Items.");
            System.out.println("2.  List of Supplier.");
            System.out.println("3.  Display Requisition.");
            System.out.println("4.  Generate Purchase Order.");
            System.out.println("5.  List of Purchaser Orders.");
            System.out.println("6.  Update Info.");
            System.out.println("7.  View Own Info.");
            System.out.println("8.  Log out.");
            System.out.print("\nEnter your choice: ");
            int choice = validateChoice(1,8);
            switch(choice){
                case 1:
                    it.view();
                    break;
                case 2:
                    sp.view();
                    break;
                case 3:
                    pr.view();
                    break;
                case 4:
                    po.menu();
                    break;
                case 5:
                    po.view();
                    break;
                case 6:
                    Staff sf1 = new Staff(getUsername());
                    sf1.updateInfo();
                    break;
                case 7:
                    Staff sf2 = new Staff(getUsername());
                    sf2.viewOwnInfo();
                case 8:
                    System.out.println("\nSee you again," + getUsername() + ".\n");
                    Staff sf3 = new Staff();
                    sf3.login();
                    break;
              default:
                break;
            }
        }
    }
    
}

