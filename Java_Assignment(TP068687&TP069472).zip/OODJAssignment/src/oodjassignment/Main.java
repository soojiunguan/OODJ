package oodjassignment;

public class Main {
    public static void main(String[] args) {
        Staff staff = new Staff();
        staff.login();
    }
}
