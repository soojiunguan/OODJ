package oodjassignment;

public interface Function {
    public void add();
    public void edit();
    public void delete();
    public void view();
    public void search();
    public void menu();
}
