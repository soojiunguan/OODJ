package oodjassignment;
import static oodjassignment.Validation.validateChoice;

public class SalesManager extends Staff{
    Item it = new Item();
    Supplier sp = new Supplier();
    DailySalesEntry ds = new DailySalesEntry();
    PurchaseRequisition pr = new PurchaseRequisition(getUsername());
    PurchaseOrder po = new PurchaseOrder();

    public SalesManager(String username) {
        super(username);
    }

    public void menu(){
        while(true){
            System.out.println("\n******************");
            System.out.println("Sales Manager Menu");
            System.out.println("******************\n");
            System.out.println("1.  Item Entry.");
            System.out.println("2.  Supplier Entry.");
            System.out.println("3.  Daily Item-wise Sales Entry.");
            System.out.println("4.  Create Purchase Requisition.");
            System.out.println("5.  Display Requisition.");
            System.out.println("6.  List of Purchaser Orders.");
            System.out.println("7.  Update Info.");
            System.out.println("8.  View Own Info.");
            System.out.println("9.  Log Out");
            System.out.print("\nEnter your choice: ");
            int choice = validateChoice(1,9);
            switch(choice){
                case 1:
                    it.menu();
                    break;
                case 2:
                    sp.menu();
                    break;
                case 3:
                    ds.menu();
                    break;
                case 4:
                    pr.menu();
                    break;
                case 5:
                    pr.view();
                    break;
                case 6:
                    po.view();
                    break;
                case 7:
                    Staff sf1 = new Staff(getUsername());
                    sf1.updateInfo();
                    break;
                case 8:
                    Staff sf2 = new Staff(getUsername());
                    sf2.viewOwnInfo();
                    break;
                case 9:
                    System.out.println("\nSee you again," + getUsername() + ".\n");
                    Staff sf3 = new Staff();
                    sf3.login();
                    break;
                default:
                    System.out.println("Please choose valid option!");
            }
        }
    }
}

