package oodjassignment;
import java.util.List;
import java.util.Scanner;
import static oodjassignment.Validation.validateChoice;

public class Supplier extends Person implements Function{
    private String supplierCode,address;
    private final String PREFIX = "SP";
    Scanner sr = new Scanner(System.in);
    FileHandle spfh = new FileHandle("supplier.txt");
    FileHandle itfh = new FileHandle("item.txt");
    
    public Supplier() {
    }

    public Supplier(String supplierCode, String name, String phoneNumber, String email, String address) {
        super(name, phoneNumber, email);
        this.supplierCode = supplierCode;
        this.address = address;
    }

    @Override
    public String toString() {
        return  supplierCode + "," + super.toString() + "," + address;
    }

    public String getSupplierCode() {
        return this.supplierCode;
    }

    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    @Override
    public void add() {
        setSupplierCode(spfh.generateId(PREFIX));
        System.out.println("\nPlease enter supplier name: ");
        String name = spfh.isNameExists(sr.nextLine());
        setName(name);
        System.out.println("Please enter supplier phone number: ");
        setPhoneNumber(sr.nextLine());
        System.out.println("Please enter supplier email address: ");
        setEmail(sr.nextLine());
        System.out.println("Please enter supplier address: ");
        setAddress(sr.nextLine());
        System.out.println("Congratulations! Supplier added successfully!");
        //setItemCode(null);
        spfh.write(toString());
        while(true){
            System.out.println("\nAny items from this supplier to add? \n1. Yes\n2. No");
            System.out.println("Choose 1 or 2: ");
            int addItemChoice = validateChoice(1,2);
            if(addItemChoice == 1){
                Item newItem = new Item();
                newItem.setItemCode(itfh.generateId("ITEM"));
                System.out.println("\nEnter name of the new item: ");
                newItem.setItemName(sr.nextLine());
                newItem.setStock(0);
                newItem.setSupplierID(getSupplierCode());
                newItem.selectCategory();
                System.out.println("\nCongratulations! Item added successfully!\n");
                itfh.write(newItem.toString());
            }
            else if(addItemChoice == 2){
                break;
            }
        }
    }

    @Override
    public void edit() {
        if(!spfh.isFileEmpty()){
            System.out.println("\nPlease provide supplier code that you wish to edit: ");
            String idToEdit = sr.nextLine();
            //String supplierToUpdate  = spfh.checkIdExist(idToEdit);
            String[] supplierToUpdate = spfh.isIdExists(idToEdit);
            if(supplierToUpdate != null){
                System.out.println("\nPlease choose which component.");
                System.out.println("1.Name");
                System.out.println("2.Phone Number");
                System.out.println("3.Email address");
                System.out.println("4.Address");
                System.out.println("\nEnter your choice: ");
                int choice = validateChoice(1,4);
                System.out.println("\nEnter changed content: ");
                String content = sr.nextLine();
                switch (choice) {
                    case 1:
                        supplierToUpdate[1] = content;
                        break;
                    case 2:
                        supplierToUpdate[2] = content;
                        break;
                    case 3:
                        supplierToUpdate[3] = content;
                        break;
                    case 4:
                        supplierToUpdate[4] = content;
                        break;
                    default:
                        System.out.println("\nInvalid choice.\n");
                        return;
                }
                setSupplierCode(supplierToUpdate[0]);
                setName(supplierToUpdate[1]);
                setPhoneNumber(supplierToUpdate[2]);
                setEmail(supplierToUpdate[3]);
                setAddress(supplierToUpdate[4]);
                spfh.edit(idToEdit, toString());
                System.out.println("\nCongratulations! Supplier information updated successfully!\n");
            }
            else{
                System.out.println("\nPlease enter an existing supplier code.\n");
            }
        }
    }

    @Override
    public void delete() {
        if(!spfh.isFileEmpty()){
            System.out.println("\nPlease enter supplier code that you want to delete: ");
            String[] idToDelete = spfh.isIdExists(sr.nextLine());
            System.out.println("\nCongratulations! The supplier deleted successfully!\n");
            spfh.delete(idToDelete[0]);
        }
    }

    private void showSuppliedItem(String supplierID){
        List<String> allITs = itfh.read();
        int count = 1;
        for (String line : allITs) {
            String[] component = line.split(",");
            if (component[3].equals(supplierID)) {
                System.out.println("Supplied item " + count + ": " + component[0]);
                count ++;
            }
        }
    }
        
    @Override
    public void view() {
        spfh.isFileEmpty();
        List<String> allSPs = spfh.read();
        for (String line : allSPs) {
            String[] component = line.split(",");
            if (component.length != 0) {
                System.out.println("\n\n*****************************");
                System.out.println("    Supplier Code: " + component[0]);
                System.out.println("*****************************");
                System.out.println("Name: " + component[1]);
                System.out.println("Phone Number: " + component[2]);
                System.out.println("Email: " + component[3]);
                System.out.println("Address: " + component[4]);
                showSuppliedItem(component[0]);
                System.out.println("*****************************");
            }
        }
    }
    
    @Override
    public void search(){
        System.out.println("\nPlease enter supplier code or name you want to search: ");
        String[] output = spfh.showSearchResult();
        if (output != null) {
            System.out.println("\nSupplier code: " + output[0] + "\nName: " + output[1] + "\nPhone number: " + output[2] + "\nEmail: " + output[3] + "\nAddress: " + output[4] + "\n");
            showSuppliedItem(output[0]);
        }
        else{
            System.out.println("\nNo results found.\n");
        }
    }
    
    @Override
    public void menu() {
        generalMenu("Supplier Menu");
    }
}