package oodjassignment;
import java.util.List;
import static oodjassignment.Validation.*;

public class Item extends WholeSystem implements Function{
    enum Category {
        Fresh_Food,
        Fresh_Produce,
        Grocery,
        INVALID
    }
    private final String PREFIX = "ITEM";
    FileHandle itfh = new FileHandle("item.txt");
    FileHandle spfh = new FileHandle("supplier.txt");
    private String itemCode;
    private String itemName;
    private int stock;
    private String supplierID;
    private Category category;

    public Item() {
    }

    public Item(String itemCode, String itemName, int stock, String supplierID, Category category) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.stock = stock;
        this.supplierID = supplierID;
        this.category = category;
    }

    @Override
    public String toString() {
        return itemCode + "," + itemName + "," + stock + "," + supplierID + "," + category;
    }

    public String getItemCode() {
        return this.itemCode;
    }

    public String getItemName() {
        return this.itemName;
    }
    
    public int getStock() {
        return this.stock;
    }

    public String getSupplierID() {
        return this.supplierID;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public void updateStock(int amount) {
        this.stock -= amount;
    }

    public void addStock(int amount) {
        this.stock += amount;
    }

    @Override
    public void add(){
        System.out.println("\n1. Add new item.");
        System.out.println("2. Add stock of existing item.");
        System.out.print("\nEnter choice: ");
        int addChoice =validateChoice(1,2);
        switch(addChoice){
        case 1:
            setItemCode(itfh.generateId(PREFIX));
            System.out.println("\nPlease enter item name: ");
            setItemName(sr.nextLine());
            System.out.println("Please enter the quantity (stock): ");
            int stockInput = validateQuantityInput(sr.nextLine());
            setStock(stockInput);
            System.out.println("Please enter supplier code of this item: ");
            String[] supplierCodeInput = spfh.isIdExists(sr.nextLine());
            setSupplierID(supplierCodeInput[0]);
            selectCategory();
            System.out.println("\nCongratulations! item added successfully!\n");
            itfh.write(toString());
            break;
        case 2:
            System.out.println("\nPlease provide item code that you wish to add stock: ");
            String[] itemToAdd = itfh.isIdExists(sr.nextLine());
            System.out.println("How much do you want to add: ");
            int addToStock = validateQuantityInput(sr.nextLine());
            setStock(Integer.parseInt(itemToAdd[2]) + addToStock);
            setItemCode(itemToAdd[0]);
            setItemName(itemToAdd[1]);
            setSupplierID(itemToAdd[3]);
            setCategory(Category.valueOf(itemToAdd[4]));
            System.out.println("\nCongratulations! stock added successfully!\n");
            itfh.edit(getItemCode(), toString());
            break;
        default:
            break;
        }
    }
    
    public void selectCategory() {
        System.out.println("\nSelect Category:");
        System.out.println("1. Fresh Food");
        System.out.println("2. Fresh Produce");
        System.out.println("3. Grocery");
        System.out.print("\nEnter the category number (1/2/3): ");
        int categoryChoice =validateChoice(1,3);
        switch (categoryChoice) {
            case 1:
                setCategory(Category.Fresh_Food);
                break;
            case 2:
                setCategory(Category.Fresh_Produce);
                break;
            case 3:
                setCategory(Category.Grocery);
                break;
            default:
                break;
        }
    }
    
    @Override
    public void edit(){
        if(!itfh.isFileEmpty()){
            String content = null;
            System.out.println("\nPlease provide item code that you wish to edit: ");
            String[] itemToUpdate = itfh.isIdExists(sr.nextLine());
            setItemCode(itemToUpdate[0]);
            setItemName(itemToUpdate[1]);
            setStock(Integer.parseInt(itemToUpdate[2]));
            setSupplierID(itemToUpdate[3]);
            System.out.println("\nPlease choose which component.");
            System.out.println("1. Item Name");
            System.out.println("2. Stock");
            System.out.println("3. Supplier ID");
            System.out.println("4. Category");
            System.out.println("\nEnter your choice: ");
            int choice = validateChoice(1, 4);
            if(choice != 4){
                System.out.println("\nEnter changed content: ");
                content = sr.nextLine();
            }
            switch (choice) {
                case 1:
                    setItemName(content);
                    break;
                case 2:
                    setStock(validateQuantityInput(content));
                    break;
                case 3:
                    String[] supplierCodeInput = spfh.isIdExists(content);
                    setSupplierID(supplierCodeInput[0]);
                    break;
                case 4:
                    selectCategory();
                    break;
                default:
                    System.out.println("\nInvalid choice.\n");
            }
            itfh.edit(getItemCode(), toString());
            System.out.println("\nCongratulations! Item information updated successfully!\n");  
        }
    }

    @Override
    public void delete(){
        if(!itfh.isFileEmpty()){
            System.out.println("\nPlease enter item code that you want to delete: ");
            String[] idToDelete = itfh.isIdExists(sr.nextLine());
            System.out.println("\nCongratulations! The item deleted successfully!\n");
            itfh.delete(idToDelete[0]);
        }
    }

    @Override
    public void view(){
        itfh.isFileEmpty();
        List<String> lines = itfh.read();
        for (String line : lines) {
            String[] component = line.split(",");
            if (component.length != 0) {
                System.out.println("\n\n*****************************");
                System.out.println("     Item Code: " + component[0]);
                System.out.println("*****************************");
                System.out.println(" Item Name: " + component[1]);
                System.out.println(" Quantity: " + component[2]);
                System.out.println(" Supplier Code: " + component[3]);
                System.out.println(" Category: " + component[4]);
                System.out.println("*****************************");
            }
        }
    }

    @Override
    public void search(){
        System.out.println("\nPlease enter item code or name you want to search: ");
        String[] output = itfh.showSearchResult();
        if (output != null) {
            System.out.println("\nItem code: " + output[0] + "\nName: " + output[1] + "\nStock: " + output[2] + "\nSupplier code: " + output[3] + "\ncatgeory: " + output[4] + "\n");
        }
        else{
            System.out.println("\nNo results found.\n");
        }
    }
    
    @Override
    public void menu(){
        generalMenu("Item Menu");
    }
    
}












