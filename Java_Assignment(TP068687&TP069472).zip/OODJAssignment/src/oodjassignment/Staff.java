package oodjassignment;
import java.text.ParseException;
import java.util.List;
import static oodjassignment.Validation.currentDate;
import static oodjassignment.Validation.dateFormat;
import static oodjassignment.Validation.validateChoice;

public class Staff extends Person {
    enum UserRole {
        SM,
        PM,
        ADMIN,
        INVALID
    }
    FileHandle sffh = new FileHandle("staff.txt");
    FileHandle itfh = new FileHandle("item.txt");
    FileHandle prfh = new FileHandle("PR.txt");
    private String username;
    private String password;
    private UserRole role;

    public Staff(String username, String name, String phoneNumber, String email, String password, UserRole role) {
        super(name, phoneNumber, email);
        this.username = username;
        this.password = password;
        this.role = role;
    }
    
    public Staff(String username){
        this.username = username;
    }
    
    public Staff() {
    }

    @Override
    public String toString() {
        return username + ',' + super.toString() + ","  + password + "," + role;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public void selectRole(){
        System.out.println("\nSelect Role:");
        System.out.println("1. Sales Manager");
        System.out.println("2. Purchase Manager");
        System.out.println("3. Admin");
        System.out.print("\nEnter the role number (1/2/3): ");
        int roleChoice =validateChoice(1,3);
        switch (roleChoice) {
            case 1:
                setRole(UserRole.SM);
                break;
            case 2:
                setRole(UserRole.PM);
                break;
            case 3:
                setRole(UserRole.ADMIN);
                break;
            default:
                break;
        }
    }
    
    public void addStaff() {
        System.out.println("\nPlease enter name: ");
        setName(sr.nextLine());
        System.out.println("Please enter phone number: ");
        setPhoneNumber(sr.nextLine());
        System.out.println("Please enter email: ");
        setEmail(sr.nextLine());
        System.out.println("Please enter username: ");
        String usernameToAdd = sffh.noIdExists(sr.nextLine());
        setUsername(usernameToAdd);
        while(true){
            System.out.println("Please enter password: ");
            setPassword(sr.nextLine());
            System.out.println("Please enter confirm password: ");
            String cpassword = sr.nextLine();
            if(getPassword().equals(cpassword)){
                break;
            }
            else{
                System.out.println("Passwords do not match. Please try again.");
            }
        }
        selectRole();
        System.out.println("\nCongratulations! The staff added successfully!\n");
        sffh.write(toString());
    }
    
    public void deleteStaff(){
        System.out.println("\nPlease enter username of the staff you want to delete: ");
        String[] usernameToDelete = sffh.isIdExists(sr.nextLine());
        System.out.println("\nCongratulations! The staff deleted successfully!\n");
        sffh.delete(usernameToDelete[0]);
    }
    
    public void searchStaff(){
        System.out.println("\nPlease enter username or name you want to search: ");
        String[] output = sffh.showSearchResult();
        if (output != null) {
                System.out.println("\n\n*****************************");
                System.out.println("    Username: " + output[0]);
                System.out.println("*****************************");
                System.out.println("Name: " + output[1]);
                System.out.println("Phone Number: " + output[2]);
                System.out.println("Email: " + output[3]);
                System.out.println("Password: " + output[4]);
                System.out.println("Role: " + output[5]);
                System.out.println("*****************************");        }
        else{
            System.out.println("\nNo results found.\n");
        }
    }
    
    public void login() {
        String title = "\nPURCHASE ORDER MANAGEMENT SYSTEM\n";
        String symbol = "*".repeat(title.length()-1);
        System.out.println(symbol + title + symbol + "\n");
        refreshPRStatus(); // check whether the date is expired or not
        while (true) {
            System.out.print("Please enter your username: ");
            String username = sr.nextLine();
            String correctPassword = null;
            String role = null;
            for (String line : sffh.read()) {
                String[] components = line.split(",");
                if (components[0].trim().equals(username)) {
                    correctPassword = components[4].trim();
                    role = components[5].trim();
                    break;
                }
            }
            // check if the username exists
            if (correctPassword == null) {
                System.out.println("\nUsername doesn't exist! Please try again.\n");
            }
            else{
                System.out.print("\nPlease enter your password: ");
                String enteredPassword = sr.nextLine();
                if (enteredPassword.equals(correctPassword)) {
                    System.out.println("\nSuccessfully logged in! Welcome back, " + username + ".");
                    // role-based actions
                    switch (role) {
                        case "SM":
                            SalesManager sm = new SalesManager(username);
                            itfh.isStockLessThan5();
                            sm.menu();
                            break;
                        case "PM":
                            PurchaseManager pm = new PurchaseManager(username);
                            prfh.PrNeedToApprove();
                            pm.menu();
                            break;
                        case "ADMIN":
                            Admin admin = new Admin(username);
                            admin.menu();
                            break;
                        default:
                            System.out.println("\nInvalid role!\n");
                    }
                    break; // exit the loop after successful login
                } else {
                    System.out.println("\nWrong password!\n");
                }
            }
        }
    }
    
    public void refreshPRStatus(){
        List<String> prData = prfh.read();
        for (int i = 0; i < prData.size(); i++) {
            String[] pr = prData.get(i).split(",");
            try {
                if(pr[6].equals("Pending") && dateFormat.parse(pr[3]).compareTo(currentDate)< 0){
                    pr[6] = "Expired";
                    prData.set(i, String.join(",", pr));
                }
            } catch (ParseException ex) {
                System.out.println("\nThere are some problems while parsing the date.\n");
            }
        }
        prfh.overwrite("");
        for (String dsCode : prData) {
            prfh.write(dsCode);
        }
    }
    
    public void updateInfo() {
        String Username = getUsername();
        String idToEdit;
        String content = null;
        int count = 0;
        int choice;
        if (Username.equals("admin")) {
            count = 1;
        }
        if(count == 1) {
        System.out.println("""
                           \n\u001b[34mHint: Enter ur username if you would like to edit yourself.\u001b[0m
                           Please provide username of the staff that you wish to update: """);
        idToEdit = sr.nextLine();
        }
        else{
            idToEdit = getUsername();
        }
        String[] staffToUpdate = sffh.isIdExists(idToEdit);
        Staff sf = new Staff();
        if (staffToUpdate != null) {
            System.out.println("\nPlease choose which component.");
            System.out.println("1. Name");
            System.out.println("2. Phone Number");
            System.out.println("3. Email address");
            System.out.println("4. Password");
            if (count == 1) {
                System.out.println("5. Role");
                System.out.println("6. Username");
            }
            System.out.println("\nEnter your choice: ");
            if(count == 1){
                choice = validateChoice(1,6);
            }
            else{
                choice = validateChoice(1,4);
            }
            if(choice == 5){
                sf.selectRole();
            }
            else{
                System.out.println("\nEnter changed content.");
                content = sr.nextLine();
            }
            if (choice == 1) {
                staffToUpdate[1] = content;
            } else if (choice == 2) {
                staffToUpdate[2] = content;
            } else if (choice == 3) {
                staffToUpdate[3] = content;
            } else if (choice == 4) {
                staffToUpdate[4] = content;
            } else if (choice == 5 && count == 1) {
                UserRole userRole = sf.getRole();
                String userRoleString = userRole.toString();
                staffToUpdate[5] = userRoleString;   
            } else if (choice == 6 && count == 1) {
                staffToUpdate[0] = content;
            } else {
                System.out.println("\nInvalid choice.\n");
            }
            sf.setUsername(staffToUpdate[0]);
            sf.setName(staffToUpdate[1]);
            sf.setPhoneNumber(staffToUpdate[2]);
            sf.setEmail(staffToUpdate[3]);
            sf.setPassword(staffToUpdate[4]);
            sf.setRole(UserRole.valueOf(staffToUpdate[5]));
            sffh.edit(idToEdit, sf.toString());
            System.out.println("\nCongratulations! Staff information updated successfully!\n");
        }
    }
    
    public void viewOwnInfo(){
        List<String> allSFs = sffh.read();
        for (String line : allSFs) {
            String[] component = line.split(",");
            if (component[0].equals(getUsername())) {
                System.out.println("\n\n*****************************");
                System.out.println("    Username: " + component[0]);
                System.out.println("*****************************");
                System.out.println("Name: " + component[1]);
                System.out.println("Phone Number: " + component[2]);
                System.out.println("Email: " + component[3]);
                System.out.println("Role: " + component[5]);
                System.out.println("*****************************");
            }
        }
        System.out.println("\nType Enter to continue...");
        sr.nextLine();
    }
    
}
