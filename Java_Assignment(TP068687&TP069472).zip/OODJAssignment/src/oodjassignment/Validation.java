package oodjassignment;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validation {
    private static Scanner sr = new Scanner(System.in);
    static Date currentDate = new Date(); // get the current date
    static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    public static int validateChoice(int minChoice, int maxChoice) {
        int choice;
        while (true) {
            try {
                choice = Integer.parseInt(sr.nextLine());
                if (choice >= minChoice && choice <= maxChoice) {
                    return choice; // Valid input
                } else {
                    System.out.println("\nInvalid choice. Please choose a valid option.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input. Please enter a valid menu choice.");
            }
        }
    }

    public static int validateQuantityInput(String input) {
        while (true) {
            try {
                int quantityInput = Integer.parseInt(input);
                if (quantityInput <= 0) {
                    System.out.println("\nQuantity cannot be negative and zero. Please enter a valid quantity.");
                } else {
                    return quantityInput; // valid input, exit loop
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. \nPlease enter a valid integer for quantity:");
            }
            input = sr.nextLine(); // prompt for input again within the loop
        }
    }
    
   
    public static String validateDate(String input) {
        while (true) {
            try {
                Date userDate = dateFormat.parse(input);
                // check if the user's date is not earlier than the current date
                if (userDate.compareTo(currentDate) >= 0) {
                    return input; // Exit the loop if the date is valid
                } else {
                    System.out.println("\nDate is earlier than the current date. Please try again.");
                    input = sr.nextLine();
                }
            } catch (ParseException e) {
                System.out.println("\nInvalid date format. Please enter the date in yyyy-MM-dd format.");
                input = sr.nextLine();
            }
        }
    }
    
    public static int validateOverStock(String id, int quantity){
        FileHandle itfh = new FileHandle("item.txt");
        String[] IdtoUpdateStock = itfh.getIDinfo(id);
        while(true){
            if((Integer.parseInt(IdtoUpdateStock[2])-quantity)>=0){
                return quantity;
            }
            else{
                System.out.println("\nInput quantity is over stock.\nPlease enter again: ");
                quantity = validateQuantityInput(sr.nextLine());
            }
        }
    }
    
}
