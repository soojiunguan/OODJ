package oodjassignment;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import oodjassignment.Item.Category;
import static oodjassignment.Validation.*;

public class DailySalesEntry{
    private String DSCode, itemCode, Date;
    private int quantity;
    private final String PREFIX = "DS";
    CurrentDate date = new CurrentDate();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Scanner sr = new Scanner(System.in);
    FileHandle dsfh = new FileHandle("DS.txt");
    FileHandle itfh = new FileHandle("item.txt");

    public DailySalesEntry () {
    }

    public DailySalesEntry(String DSCode, String itemCode, int quantity, String Date) {
        this.DSCode = DSCode;
        this.itemCode = itemCode;
        this.quantity = quantity;
        this.Date = Date;
    }

    @Override
    public String toString() {
        return DSCode + "," + itemCode + "," + quantity + "," + Date;
    }

    public String getDSCode() {
        return DSCode;
    }

    public void setDSCode(String DSCode) {
        this.DSCode = DSCode;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    private Date removeTimeFromDate(Date date) {
        try {
            return dateFormat.parse(dateFormat.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    // check whether today's daily sales 
    public boolean checker() {
        List<String> allDSs = dsfh.read(); 
        Date currentDate = new Date(); 
        currentDate = removeTimeFromDate(currentDate); 
        for (String line : allDSs) {
            String[] dsData = line.split(",");
            try {
                Date temp = dateFormat.parse(dsData[3]);
                temp = removeTimeFromDate(temp); // remove the time portion
                if (temp.compareTo(currentDate) == 0) { // check whether the date in the file is equal to the current date
                    System.out.println("\nToday's sales data has already been created. \nIf you need to make any changes or add new items, please use the edit function.\n");
                    return false;
                }
            } catch (ParseException ex) {
                System.out.println("\nThere are some problems while comparing the date.\n");
            }
        }
        return true;
    }
    
    public void add() {
        boolean continueAdding = true;
        setDSCode(dsfh.generateId(PREFIX));
        while (continueAdding) {
            System.out.println("Please enter item code: ");
            String[] ID = itfh.isIdExists(sr.nextLine());
            setItemCode(ID[0]);
            System.out.println("Please enter its quantity: ");
            int quantityInput = validateQuantityInput(sr.nextLine());
            quantityInput = validateOverStock(getItemCode(),quantityInput);
            setQuantity(quantityInput);
            setDate(date.toString());
            System.out.println("\nCongratulations! item added successfully!\n");
            dsfh.write(toString());
            String[] component = itfh.isIdExists(itemCode);
            Item item = new Item(component[0], component[1], Integer.parseInt(component[2]), component[3], Category.valueOf(component[4]));
            item.updateStock(quantityInput);
            itfh.edit(itemCode, item.toString());
            // ask the user if they want to continue adding items
            System.out.println("\nDo you want to add another item? (yes/no)");
            String userInput = sr.nextLine().trim().toLowerCase();
            if (!userInput.equals("yes")) {
                continueAdding = false;
            }
        }
    }

    public void edit() {
        if(!dsfh.isFileEmpty()){
            System.out.println("\nPlease provide Daily Sales code that you wish to edit: ");
            String[] DSToUpdate = dsfh.isIdExists(sr.nextLine());
            boolean continueEditting = true;
            while(continueEditting){
                List<String> allDSs = dsfh.read();
                List<String> dsCodesToEdit = new ArrayList<>();
                List<String> dsCodesNotToEdit = new ArrayList<>();
                for (String line : allDSs) {
                    String[] dsData = line.split(",");
                    if (dsData[0].equals(DSToUpdate[0])) {
                        dsCodesToEdit.add(line);
                    } else {
                        dsCodesNotToEdit.add(line);
                    }
                }
                System.out.println("DS Lines for Editing:");
                showResult(dsCodesToEdit);
                System.out.println("\n" + String.valueOf(Integer.toString(dsCodesToEdit.size() + 1)) + ". Add new Item");
                System.out.println("\nPlease choose which DS line to edit (1-" + String.valueOf(Integer.toString(dsCodesToEdit.size() + 1)) + "):");
                // validate choice and get choice
                int choice = validateChoice(1, dsCodesToEdit.size() + 1);

                if (choice <= dsCodesToEdit.size()) {
                    String selectedDSLine = dsCodesToEdit.get(choice - 1);
                    String[] dsData = selectedDSLine.split(",");
                    System.out.println("\nSelect an action:");
                    System.out.println("1. Modify Sales Item");
                    System.out.println("2. Remove Sales Item");
                    System.out.println("\nEnter your choice: ");
                    int action = validateChoice(1, 2);
                    String[] component = itfh.getIDinfo(dsData[1]);
                    Item item = new Item(component[0], component[1], Integer.parseInt(component[2]), component[3], Category.valueOf(component[4]));
                    // Modify Sales Item
                    item.addStock(Integer.parseInt(dsData[2]));
                    itfh.edit(item.getItemCode(), item.toString());
                    switch (action) {
                        case 1:
                            System.out.print("\nEnter the new Quantity: ");
                            int quantityInput = validateQuantityInput(sr.nextLine());
                            quantityInput = validateOverStock(item.getItemCode(), quantityInput);
                            dsData[2] = String.valueOf(quantityInput);
                            item.updateStock(quantityInput);
                            itfh.edit(item.getItemCode(), item.toString());
                            dsCodesToEdit.set(choice - 1, String.join(",", dsData));
                            break;
                        case 2:
                            // Remove Sales Item
                            dsCodesToEdit.remove(choice - 1);
                            System.out.println("\nSales Item removed.\n");
                            break;
                        default:
                            System.out.println("\nInvalid action.\n");
                    }
                } else if (choice == dsCodesToEdit.size() + 1) { //add new item in same DS Code
                    String[] dsData = dsCodesToEdit.get(0).split(",");
                    setDSCode(dsData[0]);
                    setDate(dsData[3]);
                    System.out.print("\nEnter Item Code: ");
                    String[] ItemCodeInput = itfh.isIdExists(sr.nextLine());
                    setItemCode(ItemCodeInput[0]);
                    System.out.print("Enter Quantity: ");
                    int quantityInput = validateQuantityInput(sr.nextLine());
                    quantityInput = validateOverStock(getItemCode(), quantityInput);
                    setQuantity(quantityInput);
                    // if added item is already added in file just add the quantity
                    boolean itemExists = false; // Flag to check if the item exists in dsCodesToEdit
                    for (int i = 0; i < dsCodesToEdit.size(); i++) {
                        String[] dsDATA = dsCodesToEdit.get(i).split(",");
                        if (dsDATA[1].equals(ItemCodeInput[0])) {
                            dsDATA[2] = Integer.toString(Integer.parseInt(dsDATA[2]) + getQuantity());
                            dsCodesToEdit.set(i, String.join(",", dsDATA));
                            itemExists = true;
                            break;
                        }
                    }
                    if (!itemExists) {
                        // Item doesn't exist, so add new one to the list
                        String newItemData = getDSCode() + "," + getItemCode() + "," + getQuantity() + "," + getDate();
                        dsCodesToEdit.add(newItemData);
                    }
                    System.out.println("Sales Item added.");
                    Item item = new Item(ItemCodeInput[0], ItemCodeInput[1], Integer.parseInt(ItemCodeInput[2]), ItemCodeInput[3], Category.valueOf(ItemCodeInput[4]));
                    item.updateStock(quantityInput);
                    itfh.edit(ItemCodeInput[0], item.toString());
                } else {
                    System.out.println("Invalid choice for DS line.");
                }
                dsfh.overwrite("");
                for (String dsCode : dsCodesNotToEdit) {
                    dsfh.write(dsCode);
                }
                for (String dsCode : dsCodesToEdit) {
                    dsfh.write(dsCode);
                }
                System.out.println("\nDo you want to edit another item? (yes/no)");
                String userInput = sr.nextLine().trim().toLowerCase();
                if (!userInput.equals("yes")) {
                    continueEditting = false;
                }
            }
        }
    }

    public void delete() {
        if(!dsfh.isFileEmpty()){
            System.out.println("Please enter daily sales code that you want to delete: ");
            String[] idToDelete = dsfh.isIdExists(sr.nextLine());
            List<String> dsToDelete = dsfh.read();
            for (String line : dsToDelete) {
                String[] dsData = line.split(",");
                if (dsData[0].equals(idToDelete[0])) {
                    int stockAdd = Integer.parseInt(dsData[2]);
                    String[] itemData = itfh.isIdExists(dsData[1]);
                    Item item = new Item(itemData[0], itemData[1], Integer.parseInt(itemData[2]), itemData[3], Category.valueOf(itemData[4]));
                    item.addStock(stockAdd);
                    itfh.edit(item.getItemCode(), item.toString());
                }
            }
            dsfh.delete(idToDelete[0]);
            System.out.println("Congratulations! The daily sales deleted successfully!");
        }
    }

    public void view() {
        dsfh.isFileEmpty();
        List<String> lines = dsfh.read();
        showResult(lines);
        System.out.println("\nType Enter to continue...");
        sr.nextLine();
    }

    public void menu(){
        int choice;
        do{
            System.out.println("\n**************************");
            System.out.println("Daily Item-wise Sales Menu");
            System.out.println("**************************\n");
            System.out.println("1. Generate.");
            System.out.println("2. Edit.");
            System.out.println("3. Delete.");
            System.out.println("4. View.");
            System.out.println("5. Search.");
            System.out.println("6. Exit");
            System.out.println("\nEnter your choice: ");
            choice = validateChoice(1,6);
            switch(choice){
                case 1:
                    if(checker()){
                        add();
                        break;
                    }
                    else {
                        break;
                    }
                case 2:
                    edit();
                    break;
                case 3:
                    delete();
                    break;
                case 4:
                    view();
                    break;
                case 5:
                    search();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("\nPlease choose valid option!");
            }
        }while(choice != 6);
    }
    
    public void search() {
        System.out.println("\nPlease enter daily sales id you want to search: ");
        String searchCode = sr.nextLine(); 
        List<String> searchResults = dsfh.searchMultipleLine(searchCode);
        showResult(searchResults);
    }
    
    private void showResult(List<String> searchResults){
        if (searchResults != null && !searchResults.isEmpty()) {
            Map<String, List<String>> searchIdMap = new HashMap<>();
            for (String line : searchResults) {
                String[] dsData = line.split(",");
                String dsCode = dsData[0];
                // check whether there is an existing group with the same PR code
                if (searchIdMap.containsKey(dsCode)) {
                    searchIdMap.get(dsCode).add(line);
                } else {
                    List<String> newGroup = new ArrayList<>();
                    newGroup.add(line);
                    searchIdMap.put(dsCode, newGroup);
                }
            }
            for (Map.Entry<String, List<String>> entry : searchIdMap.entrySet()) {
                String dsCode = entry.getKey();
                String Date = entry.getValue().get(0).split(",")[3];
                String formattedDsCode = String.format("|%10s", dsCode);
                String formattedDate = String.format("%-15s|", Date);
                String symbol = "|---------------------------------|";
                System.out.println("\n\n" + symbol + "\n" + formattedDsCode + "\t    " + formattedDate + "\n" + symbol);
                System.out.println("| Item Code      | Quantity       |");
                System.out.println("| ---------------| ---------------|");
                for (String dsLine : entry.getValue()) {
                    String[] dsData = dsLine.split(",");
                    String itemCode = dsData[1];
                    int quantity = Integer.parseInt(dsData[2]);
                    String formattedItemCode = String.format("| %-15s", itemCode);
                    String formattedQuantity = String.format("| %-15d", quantity);
                    System.out.println(formattedItemCode + formattedQuantity + "|");
                    System.out.println("| ---------------| ---------------|");
                }
            }
        } else {
            System.out.println("\nNothing found.");
        }
    }
    
}