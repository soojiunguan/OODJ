package oodjassignment;
import java.util.List;
import java.util.Scanner;

public class Comment {
    private String prCode;
    private String purchaseManager;
    private String comment;
    Scanner sr = new Scanner(System.in);
    FileHandle cmfh = new FileHandle("comment.txt");

    @Override
    public String toString() {
        return prCode + "|" + purchaseManager + "|" + comment;
    }

    public String getPrCode() {
        return prCode;
    }

    public void setPrCode(String prCode) {
        this.prCode = prCode;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getPurchaseManager() {
        return purchaseManager;
    }

    public void setPurchaseManager(String purchaseManager) {
        this.purchaseManager = purchaseManager;
    }

    public Comment(String prCode) {
        this.prCode = prCode;
    }
    
    public void writeComment(){
        System.out.println("\nWhy do u reject this purchase requisition: ");
        setComment(sr.nextLine());
        cmfh.write(toString());
    }
    
    public void deleteComment(){
        cmfh.delete(prCode);
    }
    
    public String readComment(){
        List<String> allCMs = cmfh.read();
        for(String line: allCMs){
            String[] component = line.split("\\|");
            if(component[0].equals(getPrCode())){
                return line;
            }
        }
        return null;
    }
}
