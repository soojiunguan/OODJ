package oodjassignment;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class FileHandle {
    private final String path;
    Scanner sr = new Scanner(System.in);
    String redColorCode = "\u001B[31m"; // ANSI escape code to set text color to red color
    String resetColorCode = "\u001B[0m"; // ANSI escape code to reset text color to default
        
    public FileHandle(String path) {
        this.path = path;
    }

    public List<String> read() {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("\nAn error occurred while reading the file.\n");
        }
        return lines;
    }

    public void write(String content){
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path, true))) {
            bw.write(content + "\n");
        }
        catch (IOException e){
            System.out.println("\nAn error occurred while writing to the file.\n");
        }
    }

    public void delete(String unicode) {
        List<String> lines = read();
        List<String> updatedLines = new ArrayList<>();
        for (String line : lines) {
            String[] component = line.split(",");
            if (!component[0].trim().equals(unicode)) {
                updatedLines.add(line);
            }
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (String line : updatedLines) {
                bw.write(line);
                bw.write("\n");
            }
        } catch (IOException e) {
            System.out.println("\nAn error occurred while writing to the file.\n");
        }
    }

    public void edit(String unicode, String content) {
        List<String> lines = read();
        List<String> updatedLines = new ArrayList<>();
        for (String line : lines) {
            String[] component = line.split(",");
            if (!component[0].trim().equals(unicode)) {
                updatedLines.add(line);
            } else {
                updatedLines.add(content);
            }
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (String line : updatedLines) {
                bw.write(line);
                bw.write("\n");
            }
        } catch (IOException e) {
            System.out.println("\nAn error occurred while writing to the file.\n");
        }
    }

    public void overwrite(String content){
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path, false))) {
            bw.write(content + "");
        }
        catch (IOException e){
            System.out.println("\nAn error occurred while writing to the file.\n");
        }
    }

    public String[] getIDinfo(String idToValidate){
        for (String line : read()) {
            String[] component = line.split(",");
            if (component[0].trim().equals(idToValidate)) {
                return component;
            }
        }
        return null;
    }

    public String[] isIdExists(String id){
        while(true){
            String[] component = getIDinfo(id);
            if(component != null){
                return component;
            }
            else{
                System.out.println("\nID not Found.\nEnter again: ");
                id = sr.nextLine();
            }
        }
    }

    //use in add staff to ensure no repeat username
    public String noIdExists(String id){
        while(true){
            String[] component = getIDinfo(id);
            if(component == null){
                return id;
            }
            else{
                System.out.println("\nID exists.\nEnter again: ");
                id = sr.nextLine();
            }
        }
    }
    
  //return no existing name  
    public String isNameExists(String name) {
        while (true) {
            boolean nameExists = false;
            for (String line : read()) {
                String[] component = line.split(",");
                if (component[1].equals(name)) {
                    nameExists = true;
                    System.out.println("\nName exists. Enter again: ");
                    name = sr.nextLine();
                    break; 
                }
            }
            if (!nameExists) {
                break;
            }
        }
        return name;
    }

    public String generateId(String PREFIX){
        AtomicInteger counter = new AtomicInteger(1);
        String newId = null;
        do{
            newId = PREFIX + String.format("%03d", counter.getAndIncrement());
        }while(getIDinfo(newId) != null);
        return newId;
    }

    public void isStockLessThan5(){
        for (String line : read()) {
            String[] component = line.split(",");
            if (Integer.parseInt(component[2]) < 5) {
                System.out.println(redColorCode + "\n!!!!! The stock of " + component[0] + " is less than 5. !!!!!" + resetColorCode);
            }
        }
    }
    
    public void PrNeedToApprove(){
        int count = 0;
        for (String line : read()) {
            String[] component = line.split(",");
            if (component[6].equals("Pending")) {
                count++;
            }
        }
        if(count != 0){
            String linkingVerb;
            if(count == 1){
                linkingVerb = "is";
            }
            else{
                linkingVerb = "are";
            }
            System.out.println(redColorCode + "\n!!!!! There " + linkingVerb + " " + Integer.toString(count) + " PR need to be handled !!!!!" + resetColorCode);
        }
    }
    
    public String[] searchFile(String input) {
    for (String line : read()) {
        String[] components = line.split(",");
        if (components[0].equals(input) || components[1].equals(input)) {
            return components; // return the entire line if a match is found
        }
    }
    return null; // return null if no match is found
}
    
    public String[] showSearchResult() {
        String[] output = searchFile(sr.nextLine());
        if (output != null) {
            return output; // return the found line
        } else {
            return null;
        }
    }
    
    // search on those multiple line(same ID)
    public List<String> searchMultipleLine(String idToSearch) {
        List<String> SearchId = new ArrayList();
        for (String line : read()) {
            String[] components = line.split(",");
            if(components[0].equals(idToSearch)){
                SearchId.add(line);
            }
        }
        return SearchId;
    }
    
    public boolean isFileEmpty(){
        Path Path = Paths.get(path);
        try{
            long fileSize = Files.size(Path);
            if (fileSize <= 0){
                System.out.println(redColorCode+ "\nNothing in the file.\n" + resetColorCode);
                return true;
            }
        }
        catch (IOException e) {
            System.out.println("\nAn error occurred while reading to the file.\n");
        }
        return false;
    }
}





